// main.cpp
// Runs on LM4F120/TM4C123
// Jonathan Valvano and Daniel Valvano
// This is a starter project for the EE319K Lab 10 in C++

// Last Modified: 4/19/2018 
// http://www.spaceinvaders.de/
// sounds at http://www.classicgaming.cc/classics/spaceinvaders/sounds.php
// http://www.classicgaming.cc/classics/spaceinvaders/playguide.php
/* This example accompanies the books
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2017

   "Embedded Systems: Introduction to Arm Cortex M Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2017

 Copyright 2018 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
// ******* Possible Hardware I/O connections*******************
// Slide pot pin 1 connected to ground
// Slide pot pin 2 connected to PD2/AIN5
// Slide pot pin 3 connected to +3.3V 
// fire button connected to PE0
// special weapon fire button connected to PE1
// 8*R resistor DAC bit 0 on PB0 (least significant bit)
// 4*R resistor DAC bit 1 on PB1
// 2*R resistor DAC bit 2 on PB2
// 1*R resistor DAC bit 3 on PB3 (most significant bit)
// LED on PB4
// LED on PB5

// Backlight (pin 10) connected to +3.3 V
// MISO (pin 9) unconnected
// SCK (pin 8) connected to PA2 (SSI0Clk)
// MOSI (pin 7) connected to PA5 (SSI0Tx)
// TFT_CS (pin 6) connected to PA3 (SSI0Fss)
// CARD_CS (pin 5) unconnected
// Data/Command (pin 4) connected to PA6 (GPIO), high for data, low for command
// RESET (pin 3) connected to PA7 (GPIO)
// VCC (pin 2) connected to +3.3 V
// Gnd (pin 1) connected to ground

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "PLL.h"
#include "ST7735.h"
#include "Random.h"
#include "PLL.h"
#include "SlidePot.h"
#include "Images.h"
#include "UART.h"
#include "Timer0.h"
#include "Timer1.h"
#define PF1  (*((volatile uint32_t *)0x40025008))
#define PF2  (*((volatile uint32_t *)0x40025010))
#define PF3  (*((volatile uint32_t *)0x40025020))
#define PF4  (*((volatile uint32_t *)0x40025040))


SlidePot my(1500,0);

extern "C" void DisableInterrupts(void);
extern "C" void EnableInterrupts(void);
extern "C" void SysTick_Handler(void);

// Creating a class named Sprite.
typedef enum {dead,alive} status_t;
struct sprite{
  uint32_t x;      // x coordinate
  uint32_t y;      // y coordinate
  const unsigned short *image; // ptr->image
  status_t life;            // dead/alive
};          
typedef struct sprite sprite_t;
uint16_t BACKGROUNDCOLOR = 0x3AD2;
sprite_t bill={60,9,SmallEnemy20pointB,alive};
const uint16_t *swords[24] = {sword1,sword2,sword3,sword4,sword5,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword7};
class HeroClass{
	private:
	const unsigned short *image;
	int x;
	int y;
	int xsize;
	int ysize;
	int facing; //0 for up, 1 for right, 2 for down, 3 for left 
	int cycle;
	public:
	int action_cooldown;
	int animation;	//1 for sword facing right
	int item;	//0 for sword, 1 for 2nd item, 2 for 3rd tiem

	
	HeroClass(int px, int py){
		image = Hero;
		x = px;
		y = py;
		xsize = 10;
		ysize = 10;
		facing = 2;	//default down facing
		action_cooldown = 0;
	}
	void display(){
		if (facing == 0){
			ST7735_DrawBitmap(x, y, upHero, xsize, ysize);
		}
		if (facing == 1){
			ST7735_DrawBitmap(x, y, rightHero, xsize, ysize);
		}
		if (facing == 2){
			ST7735_DrawBitmap(x, y, downHero, xsize, ysize);
		}
		if (facing == 3){
			ST7735_DrawBitmap(x, y, leftHero, xsize, ysize);
		}
	}
	void moveDown(){
		facing = 2;
		if (x > 0){ 
			x--;
			this->display();
			ST7735_DrawFastVLine(x + xsize, y - ysize + 1, ysize, BACKGROUNDCOLOR);
		}
	}
	void moveUp(){
		facing = 0;
		if (x < ST7735_TFTWIDTH - xsize){
			x++;
			this->display();
			ST7735_DrawFastVLine(x - 1, y - ysize + 1, ysize, BACKGROUNDCOLOR);
		}
	}
	void moveLeft(){
		facing = 3;
		if (y > ysize - 1){
			y--;
			this->display();
			ST7735_DrawFastHLine(x, y + 1, xsize, BACKGROUNDCOLOR);
		}
	}
	void moveRight(){
		facing = 1;
		if (y < ST7735_TFTHEIGHT - 33){
			y++;
			this->display();
			ST7735_DrawFastHLine(x, y - ysize, xsize, BACKGROUNDCOLOR);
		}
	}
	void action(){
		if (!(action_cooldown)){
			cycle = 0;
			if (item == 0){	//sword
				if (facing == 1){	//right
					animation = 1;
				}
			}
		}
	}
	void Animation(){
		if (animation == 1){ //sword right
			ST7735_DrawBitmap(x , y + 10, swords[cycle], 10, 10);
			cycle++;
			if (cycle == 24){
				animation = 0;
				action_cooldown = 16;
			}
		}
	}
	private:
		
};

uint32_t time = 0;
void SysTick_Init(unsigned long period){
  NVIC_ST_CTRL_R = 0;																						 // disable systick during setup
	NVIC_ST_RELOAD_R = period - 1;																 // maximum reload value 
	NVIC_ST_CURRENT_R = 0;																				 // any write to current clears it
	NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R & 0x00FFFFFF) | 0x40000000; // priority 2
	NVIC_ST_CTRL_R = 0x00000007; 			
}
void PortF_Init(void){
  SYSCTL_RCGCGPIO_R |= 0x20;      // activate port F
  while((SYSCTL_PRGPIO_R&0x20) != 0x20){};
  GPIO_PORTF_DIR_R |=  0x0E;   // output on PF3,2,1 (built-in LED)
  GPIO_PORTF_PUR_R |= 0x10;
  GPIO_PORTF_DEN_R |=  0x1E;   // enable digital I/O on PF
}
void ControllerInit(void){
	ADC_Init();
	SYSCTL_RCGCGPIO_R |= 0x10;			//activate clock for port E
	volatile int delay = SYSCTL_RCGCGPIO_R;
	delay = SYSCTL_RCGCGPIO_R;
	delay = SYSCTL_RCGCGPIO_R;
	GPIO_PORTE_DIR_R &=  ~0x1F;   // input on PE4,3,2,1,0 
  GPIO_PORTE_DEN_R |=  0x1F;   // enable digital I/O on PE
}
volatile uint32_t flag;
void background(void){
  flag = 1; // semaphore
  if(bill.life == alive){
    bill.y++;
  }
  if(bill.y>155){
    bill.life = dead;
  }
}
void clock(void){
  time++;
}
void inputs(HeroClass *player1){
	if ((GPIO_PORTE_DATA_R & 0x08)){
		player1->action();
		}
	if ((GPIO_PORTE_DATA_R & 0x01)){
		player1->moveLeft();
	}
	if ((GPIO_PORTE_DATA_R & 0x04)){
		player1->moveRight();
	}
	if ((GPIO_PORTE_DATA_R & 0x10)){
		player1->moveDown();
	}
	if ((GPIO_PORTE_DATA_R & 0x02)){
		player1->moveUp();
	}
}
int main2(void){
  PLL_Init(Bus80MHz);       // Bus clock is 80 MHz 
  Random_Init(1);
  Output_Init();
  Timer0_Init(&background,1600000); // 50 Hz
  Timer1_Init(&clock,80000000); // 1 Hz
  EnableInterrupts();
  ST7735_DrawBitmap(52, 159, PlayerShip0, 18,8); // player ship middle bottom
  ST7735_DrawBitmap(53, 151, Bunker0, 18,5);
  ST7735_DrawBitmap(0, 9, SmallEnemy10pointA, 16,10);
  ST7735_DrawBitmap(20,9, SmallEnemy10pointB, 16,10);
  ST7735_DrawBitmap(40, 9, SmallEnemy20pointA, 16,10);
  ST7735_DrawBitmap(80, 9, SmallEnemy30pointA, 16,10);
  ST7735_DrawBitmap(100, 9, SmallEnemy30pointB, 16,10);
  while(bill.life == alive){
    while(flag==0){};
    flag = 0;
    ST7735_DrawBitmap(bill.x,bill.y,bill.image,16,10);
  }

  ST7735_FillScreen(0x0000);            // set screen to black
  ST7735_SetCursor(1, 1);
  ST7735_OutString((char*)"GAME OVER");
  ST7735_SetCursor(1, 2);
  ST7735_SetTextColor(ST7735_WHITE);
  ST7735_OutString((char*)"Nice try,");
  ST7735_SetCursor(1, 3);
  ST7735_OutString((char*)"Earthling!");
  ST7735_SetCursor(2, 4);
  ST7735_SetTextColor(ST7735_WHITE);
  while(1){
    while(flag==0){};
    flag = 0;
    ST7735_SetCursor(2, 4);
    ST7735_OutUDec(time);
  }

}

int main(){
	DisableInterrupts();
	PLL_Init(Bus80MHz);
	ControllerInit();
	PortF_Init();
	SysTick_Init(1333600);
	Output_Init(); //enables screen
	ST7735_FillScreen(0x3AD2);
	HeroClass player1(70,70);
	player1.display();
	EnableInterrupts();
	ST7735_DrawBitmap(0, 160-1, sidemenutest, 128, 32);
	while (1){
		PF2 ^= 0x04;
		my.Sync();
		if (player1.action_cooldown){
			player1.action_cooldown--;
		}
		if (player1.animation > 0){
			player1.Animation();
		} else {
			if ((GPIO_PORTE_DATA_R & 0x08)){
				player1.action();
			}
			if ((GPIO_PORTE_DATA_R & 0x01)){
				player1.moveLeft();
			}
			if ((GPIO_PORTE_DATA_R & 0x04)){
				player1.moveRight();
			}
			if ((GPIO_PORTE_DATA_R & 0x10)){
				player1.moveDown();
			}
			if ((GPIO_PORTE_DATA_R & 0x02)){
				player1.moveUp();
			}
			if ((my.ADCsample() <= 1100 ) && !(player1.item == 0)){
				player1.item = 0;
				ST7735_DrawBitmap(92, 160-5, sworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, unblankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, unblankitem, 30, 24);
			}
			if ((my.ADCsample() > 1100) && (my.ADCsample() < 3000) && !(player1.item == 1)){
				player1.item = 1;
				ST7735_DrawBitmap(92, 160-5, unsworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, blankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, unblankitem, 30, 24);
			}
			if ((my.ADCsample() >= 3000 ) && !(player1.item == 2)){
				player1.item = 2;
				ST7735_DrawBitmap(92, 160-5, unsworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, unblankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, blankitem, 30, 24);
			}
		}
		PF2 ^= 0x04;
		PF2 ^= 0x04;
	}
}
void SysTick_Handler(void){ // every 16.67 ms
//Similar to Lab8 except rather than grab sample,
// form a message, transmit
	PF2 ^= 0x04;	// Heartbeat
	my.Save(ADC_In());
	PF2 ^= 0x04;
	PF2 ^= 0x04;
}

