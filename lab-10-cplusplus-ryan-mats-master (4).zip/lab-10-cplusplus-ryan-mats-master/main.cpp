// main.cpp
// Runs on LM4F120/TM4C123
// Jonathan Valvano and Daniel Valvano
// This is a starter project for the EE319K Lab 10 in C++

// Last Modified: 4/19/2018 
// http://www.spaceinvaders.de/
// sounds at http://www.classicgaming.cc/classics/spaceinvaders/sounds.php
// http://www.classicgaming.cc/classics/spaceinvaders/playguide.php
/* This example accompanies the books
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2017

   "Embedded Systems: Introduction to Arm Cortex M Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2017

 Copyright 2018 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */
// ******* Possible Hardware I/O connections*******************
// Slide pot pin 1 connected to ground
// Slide pot pin 2 connected to PD2/AIN5
// Slide pot pin 3 connected to +3.3V 
// fire button connected to PE0
// special weapon fire button connected to PE1
// 8*R resistor DAC bit 0 on PB0 (least significant bit)
// 4*R resistor DAC bit 1 on PB1
// 2*R resistor DAC bit 2 on PB2
// 1*R resistor DAC bit 3 on PB3 (most significant bit)
// LED on PB4
// LED on PB5

// Backlight (pin 10) connected to +3.3 V
// MISO (pin 9) unconnected
// SCK (pin 8) connected to PA2 (SSI0Clk)
// MOSI (pin 7) connected to PA5 (SSI0Tx)
// TFT_CS (pin 6) connected to PA3 (SSI0Fss)
// CARD_CS (pin 5) unconnected
// Data/Command (pin 4) connected to PA6 (GPIO), high for data, low for command
// RESET (pin 3) connected to PA7 (GPIO)
// VCC (pin 2) connected to +3.3 V
// Gnd (pin 1) connected to ground

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
#include "PLL.h"
#include "ST7735.h"
#include "Random.h"
#include "PLL.h"
#include "SlidePot.h"
#include "Images.h"
#include "UART.h"
#include "Timer0.h"
#include "Timer1.h"
#define PF1  (*((volatile uint32_t *)0x40025008))
#define PF2  (*((volatile uint32_t *)0x40025010))
#define PF3  (*((volatile uint32_t *)0x40025020))
#define PF4  (*((volatile uint32_t *)0x40025040))


SlidePot my(1500,0);

extern "C" void DisableInterrupts(void);
extern "C" void EnableInterrupts(void);
extern "C" void SysTick_Handler(void);

// Creating a class named Sprite.
int TIME = 0;
uint16_t BACKGROUNDCOLOR = 0x3AD2;
const uint16_t *swords[24] = {sword1,sword2,sword3,sword4,sword5,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword6,sword7};
const uint16_t *swordsd[24] = {swordd1,swordd2,swordd3,swordd4,swordd5,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,swordd6,sword7};
const uint16_t *swordsl[24] = {swordl1,swordl2,swordl3,swordl4,swordl5,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,swordl6,sword7};
const uint16_t *swordsu[24] = {swordu1,swordu2,swordu3,swordu4,swordu5,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,swordu6,sword7};

uint8_t layout1[] =     {0x01, 0x05, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 00 is for floor
															  0x01, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, // 01 is rock obstacles (no more than 100)
															  0x00, 0x00, 0x06, 0x06, 0x06, 0x06, 0x06, 0x00, 0x05, 0x00,	// 02 is eyeEnemy (no more than 100)
															  0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x01,	// 03 is chest(key) (no more than 4 TOTAL) //chests must contain an floor space above
															  0x00, 0x00, 0x06, 0x00, 0x03, 0x00, 0x06, 0x00, 0x00, 0x01,	// 04 is for openChest
															  0x00, 0x02, 0x06, 0x00, 0x00, 0x00, 0x06, 0x00, 0x02, 0x00,	// 05 is chest(heart) (no more than 4 TOTAL)
															  0x00, 0x00, 0x06, 0x06, 0x00, 0x06, 0x06, 0x00, 0x00, 0x00,	// 06 is hedge
															  0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00,
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00 };
uint8_t base_layout[] =     {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 00 is for floor
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 01 is rock obstacles (no more than 100)
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 02 is eyeEnemy (no more than 100)
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 03 is chest(key) (no more than 4 TOTAL) //chests must contain an floor space above
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 04 is for openChest
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 05 is chest(heart) (no more than 4 TOTAL)
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,	// 06 is hedge
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
															  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, };

struct Obstacle{
	int x;
	int y;
	uint8_t type; //0 for rock //1 for tree
};
class Room{
	public:
	int clear;
	uint8_t *room_layout;
	Obstacle obstacles[100];
	int numObstacles;
	bool leftWall;
	bool rightWall;
	bool upWall;
	bool downWall;
	bool leftLockedDoor;
	bool rightLockedDoor;
	bool upLockedDoor;
	bool downLockedDoor;
	public:
		Room(){
			clear = 0;
			room_layout = base_layout;
			numObstacles = 0;
			leftWall = 0;
			rightWall = 0;
			upWall = 0;
			downWall = 0;
			leftLockedDoor = 0;
			rightLockedDoor = 0;
			upLockedDoor = 0;
			downLockedDoor = 0;
		}
		Room(uint8_t *layout, bool lw, bool rw, bool uw, bool dw, bool ld, bool rd, bool ud, bool dd){
			clear = 0;
			room_layout = layout;
			numObstacles = 0;
			leftWall = lw;
			rightWall = rw;
			upWall = uw;
			downWall = dw;
			leftLockedDoor = ld;
			rightLockedDoor = rd;
			upLockedDoor = ud;
			downLockedDoor = dd;
		}
		Room(Room &that){
			clear = that.clear;
			leftWall = that.leftWall;
			rightWall = that.rightWall;
			upWall = that.upWall;
			downWall = that.downWall;
			leftLockedDoor = that.leftLockedDoor;
			rightLockedDoor = that.rightLockedDoor;
			upLockedDoor = that.upLockedDoor;
			downLockedDoor = that.downLockedDoor;
			for (int i = 0; i < 100; i++){
				room_layout[i] = that.room_layout[0];
			}
		}
};
Room ROOM(layout1,0,0,0,0,1,1,1,1);



void printDec(int value){
	int count = 0;
	int i = 0;
	bool first = 0;
	while(i < 4){
		int array[4] = {10000,1000,100,10};
		while (value >= array[i]){
			value -= array[i];
			count++;
		}
		if ((count > 0) || (first)){
			first = 1;
			ST7735_OutChar(count+0x30);
		}
		i++;
	}
	ST7735_OutChar(value+0x30);
}


bool checkSpaceLeft(int y, int x, int ysize);
bool checkSpaceRight(int y, int x);
bool checkSpaceUp(int x, int xsize, int y);
bool checkSpaceDown(int x, int y);
void generateWalls(){
	int x = 27;								//top left
	while(x < 57){
		ST7735_DrawBitmap(114, x, forestWall, 14, 14);
		x = x + 14;
	}
	if (ROOM.upLockedDoor){
		ST7735_DrawBitmap(114, x + 2, doorUp, 14, 16);
	}	
	x = 85;
	while(x < 115){					//top right
		ST7735_DrawBitmap(114, x, forestWall, 14, 14);
		x = x + 14;
	}
	x = 114;
	while(x > 71){						//left top
		ST7735_DrawBitmap(x, 13, forestWall, 14, 14);
		x = x - 7;
	}
	if (ROOM.leftLockedDoor){
		ST7735_DrawBitmap(x - 9, 13, doorLeft, 16, 14);
	}
	x = 114;
	while(x > 71){						//right top
		ST7735_DrawBitmap(x, 127, forestWall, 14, 14);
		x = x - 7;
	}
	if (ROOM.rightLockedDoor){
		ST7735_DrawBitmap(x - 9, 127, doorRight, 16, 14);
	}
	x = 42;
	while(x > -2){						//left bot
		ST7735_DrawBitmap(x, 13, forestWall, 14, 14);
		x = x - 7;
	}
	x = 42;
	while(x > -2){						//right bot
		ST7735_DrawBitmap(x, 127, forestWall, 14, 14);
		x = x - 7;
	}
	x = 27;
	while(x < 57){					//bottom left
		ST7735_DrawBitmap(0, x, forestWall, 14, 14);
		x = x + 14;
	}
	if (ROOM.downLockedDoor){
		ST7735_DrawBitmap(0, x + 2, doorDown, 14, 16);
	}
	x = 85;
	while(x < 115){				//bottom right
		ST7735_DrawBitmap(0, x, forestWall, 14, 14);
		x = x + 14;
	}
	
}

bool reload_walls = 0;
void textureDown(int x, int xsize, int y, int ysize){
	int rx = (y - ysize + 1 - 14)/10;
	int ry = 10 - (x + xsize - 14)/10;
	int chunk = (10*ry)+rx-10;
	const uint16_t *texture1;
	const uint16_t *texture2;
	if ((ROOM.room_layout[chunk] == 0) || (ROOM.room_layout[chunk] == 0x02)){
		texture1 = ground;
	} else if (ROOM.room_layout[chunk] == 0x01){
		texture1 = rock;
	} else if ((ROOM.room_layout[chunk] == 0x03) || (ROOM.room_layout[chunk] == 0x05)){
		texture1 = chest;
	}	else if (ROOM.room_layout[chunk] == 0x04){
		texture1 = openChest;
	}	else if (ROOM.room_layout[chunk] == 0x06){
		texture1 = hedge;
	}	
	if ((ROOM.room_layout[chunk+1] == 0) || (ROOM.room_layout[chunk+1] == 0x02)){
		texture2 = ground;
	}else if (ROOM.room_layout[chunk+1] == 0x01){
		texture2 = rock;
	} else if ((ROOM.room_layout[chunk+1] == 0x03) || (ROOM.room_layout[chunk+1] == 0x05)){
		texture2 = chest;
	}	else if (ROOM.room_layout[chunk+1] == 0x04){
		texture2 = openChest;
	}	else if (ROOM.room_layout[chunk+1] == 0x06){
		texture2 = hedge;
	}	
	int px = ((x+xsize+16))%10;
	for (int i = 0; i < 10; i++){
		int py = (123 - (y - ysize + 1 + i))%10;
		rx = (y - ysize + 1 + i - 14)/10;
		ry = 10 - (x + xsize - 14)/10;
		int chunk2 = (10*ry)+rx-10;
		if (chunk2 > chunk){
			ST7735_FillRect(x + xsize ,y - ysize + 1 + i, 1, 1, texture2[10*(py%10) + px]);
		} else {
			ST7735_FillRect(x + xsize ,y - ysize + 1 + i, 1, 1, texture1[10*(py) + px]);
		}
	}
}
void textureUp(int x, int xsize, int y, int ysize){
	int rx = (y - ysize + 1 - 14)/10;
	int ry = 10 - (x - 1 - 14)/10;
	if (rx < 0){
		reload_walls = 1;
	}	
	int chunk = (10*ry)+rx-10;
	const uint16_t *texture1;
	const uint16_t *texture2;
	if ((chunk < 0) || (chunk > 99)){
		reload_walls = 1;
	} else if (ROOM.room_layout[chunk] == 0 || ROOM.room_layout[chunk] == 0x02){
		texture1 = ground;
	} else if (ROOM.room_layout[chunk] == 0x01){
		texture1 = rock;
	} else if ((ROOM.room_layout[chunk] == 0x03) || (ROOM.room_layout[chunk] == 0x05)){
		texture1 = chest;
	}	else if (ROOM.room_layout[chunk] == 0x04){
		texture1 = openChest;
	}	else if (ROOM.room_layout[chunk] == 0x06){
		texture1 = hedge;
	}	
	if ((chunk < 0) || (chunk > 99)){
		reload_walls = 1;
	}else if (ROOM.room_layout[chunk+1] == 0 || ROOM.room_layout[chunk+1] == 0x02){
		texture2 = ground;
	}else if (ROOM.room_layout[chunk+1] == 0x01){
		texture2 = rock;
	} else if ((ROOM.room_layout[chunk+1] == 0x03) || (ROOM.room_layout[chunk+1] == 0x05)){
		texture2 = chest;
	}	else if (ROOM.room_layout[chunk+1] == 0x04){
		texture2 = openChest;
	}	else if (ROOM.room_layout[chunk+1] == 0x06){
		texture2 = hedge;
	}	
	int px = ((x - 1 + 16))%10;
	for (int i = 0; i < 10; i++){
		int py = (123 - (y - ysize + 1 + i))%10;
		rx = (y - ysize + 1 + i - 14)/10;
		ry = 10 - (x - 1 - 14)/10;
		int chunk2 = (10*ry)+rx-10;
		if (chunk2 > chunk){
			ST7735_FillRect(x - 1 ,y - ysize + 1 + i, 1, 1, texture2[10*(py%10) + px]);
		} else {
			ST7735_FillRect(x - 1 ,y - ysize + 1 + i, 1, 1, texture1[10*(py) + px]);
		}
	}
}

void textureLeft(int x, int xsize, int y, int ysize){
	int rx = (y + 1 - 14)/10;
	int ry = 10 - (x - 14)/10;
	int chunk = (10*ry)+rx-10;
	const uint16_t *texture1;
	const uint16_t *texture2;
	if (ROOM.room_layout[chunk] == 0 || ROOM.room_layout[chunk] == 0x02){
		texture1 = ground;
	} else if (ROOM.room_layout[chunk] == 0x01){
		texture1 = rock;
	} else if ((ROOM.room_layout[chunk] == 0x03) || (ROOM.room_layout[chunk] == 0x05)){
		texture1 = chest;
	}	else if (ROOM.room_layout[chunk] == 0x04){
		texture1 = openChest;
	}	else if (ROOM.room_layout[chunk] == 0x06){
		texture1 = hedge;
	}	
	if (ROOM.room_layout[chunk-10] == 0 || ROOM.room_layout[chunk-10] == 0x02){
		texture2 = ground;
	}else if (ROOM.room_layout[chunk-10] == 0x01){
		texture2 = rock;
	} else if ((ROOM.room_layout[chunk-10] == 0x03) || (ROOM.room_layout[chunk-10] == 0x05)){
		texture2 = chest;
	}	else if (ROOM.room_layout[chunk-10] == 0x04){
		texture2 = openChest;
	}	else if (ROOM.room_layout[chunk-10] == 0x06){
		texture2 = hedge;
	}	
	int py = (123 - (y + 1))%10;
	for (int i = 0; i < 10; i++){
		int px = ((x + i + 16))%10;
		rx = (y + 1 - 14)/10;
		ry = 10 - (x + i - 14)/10;
		int chunk2 = (10*ry)+rx-10;
		if (chunk2 < chunk){
			ST7735_FillRect(x + i ,y + 1, 1, 1, texture2[10*(py%10) + px]);
		} else {
			ST7735_FillRect(x + i ,y + 1, 1, 1, texture1[10*(py) + px]);
		}
	}
}
void textureRight(int x, int xsize, int y, int ysize){
	int rx = (y - ysize - 14)/10;
	int ry = 10 - (x - 14)/10;
	int chunk = (10*ry)+rx-10;
	const uint16_t *texture1;
	const uint16_t *texture2;
	if (ROOM.room_layout[chunk] == 0 || ROOM.room_layout[chunk] == 0x02){
		texture1 = ground;
	} else if (ROOM.room_layout[chunk] == 0x01){
		texture1 = rock;
	} else if ((ROOM.room_layout[chunk] == 0x03) || (ROOM.room_layout[chunk] == 0x05)){
		texture1 = chest;
	}	else if (ROOM.room_layout[chunk] == 0x04){
		texture1 = openChest;
	}	else if (ROOM.room_layout[chunk] == 0x06){
		texture1 = hedge;
	}	
	if (ROOM.room_layout[chunk-10] == 0 || ROOM.room_layout[chunk-10] == 0x02){
		texture2 = ground;
	}else if (ROOM.room_layout[chunk-10] == 0x01){
		texture2 = rock;
	} else if ((ROOM.room_layout[chunk-10] == 0x03) || (ROOM.room_layout[chunk-10] == 0x05)){
		texture2 = chest;
	}	else if (ROOM.room_layout[chunk-10] == 0x04){
		texture2 = openChest;
	}	else if (ROOM.room_layout[chunk-10] == 0x06){
		texture2 = hedge;
	}	
	int py = (123 - (y - ysize))%10;
	for (int i = 0; i < 10; i++){
		int px = ((x + i + 16))%10;
		rx = (y - ysize - 14)/10;
		ry = 10 - (x + i - 14)/10;
		int chunk2 = (10*ry)+rx-10;
		if (chunk2 < chunk){
			ST7735_FillRect(x + i ,y - ysize, 1, 1, texture2[10*(py%10) + px]);
		} else {
			ST7735_FillRect(x + i ,y - ysize, 1, 1, texture1[10*(py) + px]);
		}
	}
}	


void textureSquare(int x, int y, int width, int height){
	reload_walls = 0;
	for(int i = 0;i < height; i++){
		textureUp(x + 1 + i, width, y, height); 
	}
	if (reload_walls){
		generateWalls();
	}
}
class HeroClass{
	private:
	int xsize;
	int ysize;
	int facing; //0 for up, 1 for right, 2 for down, 3 for left 
	int rooms;
	public:
	int keys_collected;
	int keys;
	int x;
	int y;
	int health;
	bool dead;
	int action_cooldown; 
	int animation;	//1 for sword facing right
	int cycle;	//keeps track of where it is in the animation
	int item;	//0 for sword, 1 for 2nd item, 2 for 3rd tiem
	int damage_cooldown; //counter for a few seconds of invincibility after taking damage
	int slain_STORE;
	void updateHearts(){
	if (health == 6){
		ST7735_DrawBitmap(16, 160-11, heart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, heart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	}else if (health == 5){
		ST7735_DrawBitmap(16, 160-11, halfHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, heart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	}else if (health == 4){
		ST7735_DrawBitmap(16, 160-11, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, heart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	}else if (health == 3){
		ST7735_DrawBitmap(16, 160-11, noHeart, 5, 5);
  	ST7735_DrawBitmap(16, 160-17, halfHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	}else if (health == 2){
		ST7735_DrawBitmap(16, 160-11, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	}else if (health == 1){
		ST7735_DrawBitmap(16, 160-11, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, halfHeart, 5, 5);
	}else if (health <= 0){
		ST7735_DrawBitmap(16, 160-11, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-17, noHeart, 5, 5);
		ST7735_DrawBitmap(16, 160-23, noHeart, 5, 5);
	}
}	
	void updateKeys(){
		if (keys == 0){
			ST7735_DrawBitmap(9, 160-23, blankKey, 7, 3);
			ST7735_DrawBitmap(9, 160-17, blankKey, 7, 3);
			ST7735_DrawBitmap(9, 160-11, blankKey, 7, 3);
		}else if (keys == 1){
			ST7735_DrawBitmap(9, 160-23, key, 7, 3);
			ST7735_DrawBitmap(9, 160-17, blankKey, 7, 3);
			ST7735_DrawBitmap(9, 160-11, blankKey, 7, 3);
		}else if (keys == 2){
			ST7735_DrawBitmap(9, 160-23, key, 7, 3);
			ST7735_DrawBitmap(9, 160-17, key, 7, 3);
			ST7735_DrawBitmap(9, 160-11, blankKey, 7, 3);
		}else if (keys >= 3){
			ST7735_DrawBitmap(9, 160-23, key, 7, 3);
			ST7735_DrawBitmap(9, 160-17, key, 7, 3);
			ST7735_DrawBitmap(9, 160-11, key, 7, 3);
		}
		
	};
	HeroClass(int px, int py){
		x = px;
		y = py;
		xsize = 10;
		ysize = 10;
		facing = 2;	//default down facing
		action_cooldown = 0;
		damage_cooldown = 0;
		animation = 0;
		health = 6;
		dead = 0;
		rooms = 1;
		slain_STORE = 0; //what is this?
		keys_collected = 0;
		keys = 0;
	}
	void display(){
		if (facing == 0){
			ST7735_DrawBitmap(x, y, upHero, xsize, ysize);
		}
		if (facing == 1){
			ST7735_DrawBitmap(x, y, rightHero, xsize, ysize);
		}
		if (facing == 2){
			ST7735_DrawBitmap(x, y, downHero, xsize, ysize);
		}
		if (facing == 3){
			ST7735_DrawBitmap(x, y, leftHero, xsize, ysize);
		}
	}
	void moveDown(){
		facing = 2;
		if (checkSpaceDown(x, y)){ 
			x--;
			this->display();
			textureDown(x, xsize, y, ysize);
		}
	}
	void moveUp(){
		facing = 0;
		if (checkSpaceUp(x, xsize, y)){
			x++;
			this->display();
			textureUp(x, xsize, y, ysize);
		}
	}
	void moveLeft(){
		facing = 3;
		if (checkSpaceLeft(y, x, ysize)) {
			y--;
			this->display();
			textureLeft(x, xsize, y, ysize);
		}
	}
	void moveRight(){
		facing = 1;
		if (checkSpaceRight(y, x)){
			y++;
			this->display();
			textureRight(x, xsize, y, ysize);
		}
	}
	void action(){
		if (!(action_cooldown)){
			cycle = 0;
			if (item == 0){	//sword
				if (facing == 1){	//right
					animation |= 0x01;
				}
				if (facing == 2){	//down
					animation |= 0x02;
				}
				if (facing == 3){	//left
					animation |= 0x04;
				}
				if (facing == 0){	//up
					animation |= 0x08;
				}
			}
		}
	}
	void Animation(){
		if (animation&0x01){ //sword right
			ST7735_DrawBitmap(x , y + 10, swords[cycle], 10, 10);
			cycle++;
			if (cycle == 24){
				textureSquare(x, y + 10, xsize, ysize);
				animation &= ~0x01;
				action_cooldown = 16;
				//charge spin attack?
			}
		}else if (animation&0x02){ //sword down
			ST7735_DrawBitmap(x - 10 , y, swordsd[cycle], 10, 10);
			cycle++;
			if (cycle == 24){
				textureSquare(x - 10, y, xsize, ysize);
				animation &= ~0x02;
				action_cooldown = 16;
				//charge spin attack?
			}
		}else if (animation&0x04){ //sword left
			ST7735_DrawBitmap(x, y - 10, swordsl[cycle], 10, 10);
			cycle++;
			if (cycle == 24){
				textureSquare(x, y - 10, xsize, ysize);
				animation &= ~0x04;
				action_cooldown = 16;
				//charge spin attack?
			}
		}else if (animation&0x08){ //sword up
			ST7735_DrawBitmap(x + 10, y, swordsu[cycle], 10, 10);
			cycle++;
			if (cycle == 24){
				textureSquare(x + 10, y, xsize, ysize);
				animation &= ~0x08;
				action_cooldown = 16;
				//charge spin attack?
			}
		}else if (animation&0x10){ //took damage
			ST7735_DrawBitmap(x , y, damagedHero, 10, 10);
			cycle++;
			if (cycle == 10){
				animation &= ~0x10;
				ST7735_DrawBitmap(x , y, downHero, 10, 10);
			}	
		}else if (animation&0x20){ //item got
			cycle++;
			if (cycle == 60){
				animation &= ~0x20;
				ST7735_DrawBitmap(x , y, downHero, 10, 10);
			}	
		}
	}
	void death(){
		dead = 1;
		ST7735_FillScreen(0x0000);
		ST7735_SetRotation(1);
		ST7735_SetCursor(7,4);
		ST7735_OutString("GAME OVER");
		ST7735_SetCursor(2,6);
		ST7735_OutString("Rooms Discoverd: ");
		printDec(rooms);
		ST7735_SetCursor(2,7);
		ST7735_OutString("Keys Collected: ");
		printDec(keys_collected);
		ST7735_SetCursor(2,8);
		ST7735_OutString("STORE Slain: ");
		printDec(slain_STORE);
		ST7735_SetCursor(2,10);
		ST7735_OutString("Time: ");
		printDec(TIME);
		ST7735_OutString(" Seconds");
	}
	void takeDamage(int amount){
		health-=amount;
		updateHearts();
		if (health <= 0){
		 dead = 1;
		}
		else {
			ST7735_DrawBitmap(x, y, damagedHero, xsize, ysize);
			cycle = 0;
			animation |= 0x10;
			damage_cooldown = 60;
		}
	}
	void run(){
		if (action_cooldown){
			action_cooldown--;
		}
		if (damage_cooldown){
			ST7735_DrawBitmap(x , y, bnwHero , 10, 10);
			damage_cooldown--;
		}
		if (animation){
			Animation();
		} else {
			if ((GPIO_PORTE_DATA_R & 0x08)){
				action();
			}
			if ((GPIO_PORTE_DATA_R & 0x01)){
				moveLeft();
			}
			if ((GPIO_PORTE_DATA_R & 0x04)){
				moveRight();
			}
			if ((GPIO_PORTE_DATA_R & 0x10)){
				moveDown();
			}
			if ((GPIO_PORTE_DATA_R & 0x02)){
				moveUp();
			}
			if ((my.ADCsample() <= 1100 ) && !(item == 0)){
				item = 0;
				ST7735_DrawBitmap(92, 160-5, sworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, unblankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, unblankitem, 30, 24);
			}
			if ((my.ADCsample() > 1100) && (my.ADCsample() < 3000) && !(item == 1)){
				item = 1;
				ST7735_DrawBitmap(92, 160-5, unsworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, blankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, unblankitem, 30, 24);
			}
			if ((my.ADCsample() >= 3000 ) && !(item == 2)){
				item = 2;
				ST7735_DrawBitmap(92, 160-5, unsworditem, 30, 24);
				ST7735_DrawBitmap(58, 160-5, unblankitem, 30, 24);
				ST7735_DrawBitmap(23, 160-5, blankitem, 30, 24);
			}
		}
	}
		
};
class Chest{
	public:
	int x;
	int y;
	bool contents; //0 for key, 1 for heart
	bool open;
	int chunk;
	int item_appearance_counter;
	Chest(){
		x = -20;
		y = -20;
		open = 1;
		contents = 0;
	}
	void init(int px, int py, int pcontents, int pchunk){
		x = px;
		y = py;
		contents = pcontents;
		open = 0;
		chunk = pchunk;
		item_appearance_counter = 0;
	}
	void run(HeroClass *player){
		if (!(open)){
			if ((ROOM.clear) && (x + 10 - player->x < 20) && (x + 10 - player->x > 0) && (y + 10 - player->y < 20) && (y + 10 - player->y > 0) && (player->damage_cooldown == 0)){
				ST7735_DrawBitmap(x, y, openChest, 10, 10);
				if (contents){
					ST7735_DrawBitmap(x + 12, y - 2, floorHeart, 7, 7);
				} else{
					ST7735_DrawBitmap(x + 11, y - 3, floorKey, 9, 5);
				}
				ROOM.room_layout[chunk] = 0x04; 
				open = 1;
				item_appearance_counter = 60;
				player->animation |= 0x20;
				player->cycle = 0;
			}
		} else if (item_appearance_counter){
			item_appearance_counter--;
			if (!(item_appearance_counter)){
				textureSquare(x + 10, y, 10, 10);
				if (contents){
				player->health += 2;
				if (player->health > 6) {
					player->health = 6;
				}
				player->updateHearts();
				}
				else {
					player->keys_collected++;
					player->keys++;
					player->updateKeys();
				}
			}
		}
	}	
};
class EyeballEnemy{
private:
	int health;
	int damage;
	int facing; //0 for up, 1 for right, 2 for down, 3 for left 
	int speed;
	int speedcntr; //counts 0-3 if 0-2 do not move
	int xsize;
	int ysize;
  int damage_taken; //counter that stuns the eyeball and stops it from being able to move
	int random_counter; //counts time to resample the random movement decision
	uint8_t m;
public:
	int x;
	int y;
	bool dead;
	EyeballEnemy(){
		x = -20;
		y = -20;
		dead = 1;
	}
	void init(int px, int py){
		x = px;
		y = py;
		health = 3;
		damage = 1;
		facing = 2;
		speed = 3; //1/4ths the players speed
		xsize = 10;
		ysize = 10;
		speedcntr = 0;
		dead = 0;
		damage_taken = 0;
		random_counter = 60;
		m = 0; 
	}
	void display(){
		if ((facing == 2) || ( facing == 0)){
			ST7735_DrawBitmap(x, y, Eye, xsize, ysize);
		}
		if (facing == 1){
			ST7735_DrawBitmap(x, y, rightEye, xsize, ysize);
		}
		if (facing == 3){
			ST7735_DrawBitmap(x, y, leftEye, xsize, ysize);
		}
	}

	void moveDown(int amount){		
		while (amount > 0){	
			if (speedcntr == speed){
					if (checkSpaceDown(x, y)){ 
						x--;
						textureDown(x, xsize, y, ysize);
					}
				}
			amount--;
			speedcntr++;
			speedcntr&=speed;
		}
	}
	void moveUp(int amount){
		while (amount > 0){
			if (speedcntr == speed){
				if (checkSpaceUp(x, xsize, y)){
					x++;
				  textureUp(x, xsize, y, ysize);
				}
			}
			amount--;
			speedcntr++;
			speedcntr&=speed;
		}
	}
  void moveLeft(int amount){
		while (amount > 0){
			if (speedcntr == speed){
				if (checkSpaceLeft(y, x, ysize)){
					y--;
					textureLeft(x, xsize, y, ysize);
				}
			}
			speedcntr++;
			speedcntr&=speed;
			amount--;
		}
  }
	void moveRight(int amount){
		while (amount > 0){
			if (speedcntr == speed){
				if (checkSpaceRight(y, x)){
					y++;
					textureRight(x, xsize, y, ysize);
				}
			}
			amount--;
			speedcntr++;
			speedcntr&=speed;
		}
	}
	void die(){
	 dead = 1;
	 textureSquare(x, y, 10, 10);
	 x = -20;
	 y = -20;	
	}
	void knockback(int amount){
		if (facing == 0){
			moveDown(amount);
		}
		else if (facing == 1){
			moveLeft(amount);
		}
		else if (facing == 2){
			moveUp(amount);
		}
		else if (facing == 3){
			moveRight(amount);
		}
		this->display();
	}
	void chase(HeroClass *player){
		if (damage_taken == 0){
			if (random_counter == 0){
				m = Random();
				random_counter = 60;
				PF3 ^= 0x08;
			}
			random_counter--;
			if (m < 127){ //prioritizes x direction
				if (x > player->x){
					facing = 2;
					moveDown(1);
					this->display();
				}
				else if (x < player->x){
					facing = 0;
					moveUp(1);
					this->display();
				}
				else if (y > player->y){
					facing = 3;
					moveLeft(1);
					this->display();
				}
				else if (y < player->y){
					facing = 1;
					moveRight(1);
					this->display();
				}
			} else { //prioritizes y direction
				if (y > player->y){
					facing = 3;
					moveLeft(1);
					this->display();
				}
				else if (y < player->y){
					facing = 1;
					moveRight(1);
					this->display();
				}	
				else if (x > player->x){
					facing = 2;
					moveDown(1);
					this->display();
				}
				else if (x < player->x){
					facing = 0;
					moveUp(1);
					this->display();
				}
			}
			if ((x + 10 - player->x < 20) && (x + 10 - player->x > 0) && (y + 10 - player->y < 20) && (y + 10 - player->y > 0) && (player->damage_cooldown == 0)){
				knockback(60);//if touching the player
				player->takeDamage(damage);
				damage_taken = 16;
			}
			if (((x - player->x < 20) && (x - player->x > 0) && (y + 10 - player->y < 20) && (y + 10 - player->y > 0) && (player->animation & 8) && (player->cycle == 2))
			||  ((player->x - x < 20) && (player->x - x > 0) && (y + 10 - player->y < 20) && (y + 10 - player->y > 0) && (player->animation & 2) && (player->cycle == 2))
			||  ((y - player->y < 20) && (y - player->y > 0) && (x + 10 - player->x < 20) && (x + 10 - player->x > 0) && (player->animation & 1) && (player->cycle == 2))
			||  ((player->y - y < 20) && (player->y - y > 0) && (x + 10 - player->x < 20) && (x + 10 - player->x > 0) && (player->animation & 4) && (player->cycle == 2))){
				health--;//if attacked
				if (health == 0) {
					player->slain_STORE++;
					die();
				}
				else {
					if (player->animation & 0x01){
					  moveRight(40);
					} else if (player->animation & 0x02){
					  moveDown(40);
					} else if (player->animation & 0x04){
					  moveLeft(40);
					} else if (player->animation & 0x08){
					  moveUp(40);
					}
					ST7735_DrawBitmap(x, y, damagedEye, xsize, ysize);
					damage_taken = 16;
				}		
			}
		}
		else {
			damage_taken--;
		}
	}
};

struct Storage{
	EyeballEnemy eyes[100];
	int numEyes;
	Chest chests[4];
	int num_chests;
};
Storage STORE;
bool checkSpaceLeft(int y, int x, int ysize){
	bool return_val = (y > ysize - 1 + 14);
	for(int i = 0; i < ROOM.numObstacles; i++){
		return_val = return_val && ((y != ROOM.obstacles[i].y + 10 ) || !((ROOM.obstacles[i].x + 9 >= x) && (ROOM.obstacles[i].x - 9 <= x)));
	}
	for(int i = 0; i < STORE.numEyes; i++){
		return_val = return_val && ((y != STORE.eyes[i].y + 10 ) || !((STORE.eyes[i].x + 9 >= x) && (STORE.eyes[i].x - 9 <= x)));
	}
	return return_val;
}	
bool checkSpaceRight(int y, int x){
	bool return_val = (y < ST7735_TFTHEIGHT - 33 - 14);
	for(int i = 0; i < ROOM.numObstacles; i++){
		return_val = return_val && ((y != ROOM.obstacles[i].y - 10 ) || !((ROOM.obstacles[i].x + 9 >= x) && (ROOM.obstacles[i].x - 9 <= x)));
	}
	for(int i = 0; i < STORE.numEyes; i++){
		return_val = return_val && ((y != STORE.eyes[i].y - 10 ) || !((STORE.eyes[i].x + 9 >= x) && (STORE.eyes[i].x - 9 <= x)));
	}
	return return_val;
}
bool checkSpaceUp(int x, int xsize, int y){
	bool return_val = (x < ST7735_TFTWIDTH - xsize - 14);
	for(int i = 0; i < ROOM.numObstacles; i++){
		return_val = return_val && ((x != ROOM.obstacles[i].x - 10 ) || !((ROOM.obstacles[i].y + 9 >= y) && (ROOM.obstacles[i].y - 9 <= y)));
	}
	for(int i = 0; i < STORE.numEyes; i++){
		return_val = return_val && ((x != STORE.eyes[i].x - 10 ) || !((STORE.eyes[i].y + 9 >= y) && (STORE.eyes[i].y - 9 <= y)));
	}
	return return_val;
}
bool checkSpaceDown(int x, int y){
	bool return_val = (x > 14);
	for(int i = 0; i < ROOM.numObstacles; i++){
		return_val = return_val && ((x != ROOM.obstacles[i].x + 10 ) || !((ROOM.obstacles[i].y + 9 >= y) && (ROOM.obstacles[i].y - 9 <= y)));
	}
	for(int i = 0; i < STORE.numEyes; i++){
		return_val = return_val && ((x != STORE.eyes[i].x + 10 ) || !((STORE.eyes[i].y + 9 >= y) && (STORE.eyes[i].y - 9 <= y)));
	}
	return return_val;
}
void SysTick_Init(unsigned long period){
  NVIC_ST_CTRL_R = 0;																						 // disable systick during setup
	NVIC_ST_RELOAD_R = period - 1;																 // maximum reload value 
	NVIC_ST_CURRENT_R = 0;																				 // any write to current clears it
	NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R & 0x00FFFFFF) | 0x40000000; // priority 2
	NVIC_ST_CTRL_R = 0x00000007; 			
}
void PortF_Init(void){
  SYSCTL_RCGCGPIO_R |= 0x20;      // activate port F
  while((SYSCTL_PRGPIO_R&0x20) != 0x20){};
  GPIO_PORTF_DIR_R |=  0x0E;   // output on PF3,2,1 (built-in LED)
  GPIO_PORTF_PUR_R |= 0x10;
  GPIO_PORTF_DEN_R |=  0x1E;   // enable digital I/O on PF
}
void ControllerInit(void){
	ADC_Init();
	SYSCTL_RCGCGPIO_R |= 0x10;			//activate clock for port E
	volatile int delay = SYSCTL_RCGCGPIO_R;
	delay = SYSCTL_RCGCGPIO_R;
	delay = SYSCTL_RCGCGPIO_R;
	GPIO_PORTE_DIR_R &=  ~0x1F;   // input on PE4,3,2,1,0 
  GPIO_PORTE_DEN_R |=  0x1F;   // enable digital I/O on PE
}

void displayOverlays(){
	ST7735_FillRect(0, 128, 128, 32, 0x4208);
	ST7735_DrawBitmap(92, 160-5, sworditem, 30, 24);
	ST7735_DrawBitmap(58, 160-5, unblankitem, 30, 24);
	ST7735_DrawBitmap(23, 160-5, unblankitem, 30, 24);
	ST7735_DrawBitmap(16, 160-11, heart, 5, 5);
	ST7735_DrawBitmap(16, 160-17, heart, 5, 5);
	ST7735_DrawBitmap(16, 160-23, heart, 5, 5);
	generateWalls();
}
void loadRoom(int id){
	ST7735_FillScreen(0x3AD2);
	for (int i = 0; i < 100; i++){
		int y = i%10 * 10 + 23;
		int x = 104 - (i/10 * 10);
		if (ROOM.room_layout[i] == 0x01){
			ROOM.obstacles[ROOM.numObstacles].y = y;
			ROOM.obstacles[ROOM.numObstacles].x = x;
			ROOM.obstacles[ROOM.numObstacles].type = 0;
			ROOM.numObstacles++;
		} else if (ROOM.room_layout[i] == 0x02){
			STORE.eyes[STORE.numEyes].init(x,y);
			STORE.numEyes++;
		} else if (ROOM.room_layout[i] == 0x00){
			ST7735_DrawBitmap(x, y, ground, 10, 10);
		} else if (ROOM.room_layout[i] == 0x03){		//key chest			
			STORE.chests[STORE.num_chests].init(x,y,0,i);
			STORE.num_chests++;
			ST7735_DrawBitmap(x, y, chest, 10, 10);
		} else if (ROOM.room_layout[i] == 0x04){ 
			ST7735_DrawBitmap(x, y, openChest, 10, 10);
		} else if (ROOM.room_layout[i] == 0x05){	//heart chest
			STORE.chests[STORE.num_chests].init(x,y,1,i);
			STORE.num_chests++;
			ST7735_DrawBitmap(x, y, chest, 10, 10);
		} else if (ROOM.room_layout[i] == 0x06){	//tree obstacle
			ROOM.obstacles[ROOM.numObstacles].y = y;
			ROOM.obstacles[ROOM.numObstacles].x = x;
			ROOM.obstacles[ROOM.numObstacles].type = 1;
			ROOM.numObstacles++;
		}
	}
	for (int i = 0; i < ROOM.numObstacles; i++){
		if (ROOM.obstacles[i].type == 0){
			ST7735_DrawBitmap(ROOM.obstacles[i].x, ROOM.obstacles[i].y, rock, 10, 10);
		} else {
			ST7735_DrawBitmap(ROOM.obstacles[i].x, ROOM.obstacles[i].y, hedge, 10, 10);
		}
	}
	for (int i = 0; i < STORE.numEyes; i++){
		ST7735_DrawBitmap(STORE.eyes[i].x, STORE.eyes[i].y, Eye, 10, 10);
	}
	displayOverlays();
}
int main(){
	DisableInterrupts();
	PLL_Init(Bus80MHz);
	ControllerInit();
	PortF_Init();
	SysTick_Init(1333600);
	Output_Init(); //enables screen
	Random_Init(69);
	ST7735_FillScreen(0x3AD2);
	HeroClass player1(70,70);
	ROOM.numObstacles = 0;
	STORE.numEyes = 0;
	loadRoom(0);
	player1.display();	
	int timecntr = 59;
	EnableInterrupts();
	int count;
	while (!(player1.dead)){
		timecntr--;
		if (!(timecntr)){
			TIME++;
			timecntr = 59;
		}
		my.Sync();
		count = 0;
		for(int i = 0; i < STORE.numEyes; i++){
			if (!(STORE.eyes[i].dead)){
				STORE.eyes[i].chase(&player1);
			} else{
				count++;
			}
		}
		if ((ROOM.clear == 0) && (count == STORE.numEyes)){
			ROOM.clear = 1;
		}
		for(int i = 0; i < STORE.num_chests; i++){
			STORE.chests[i].run(&player1);
		}
		player1.run();
		PF2 ^= 0x04;
		PF2 ^= 0x04;
	}
	player1.death();
}
void SysTick_Handler(void){ // every 16.67 ms
//Similar to Lab8 except rather than grab sample,
// form a message, transmit
	PF2 ^= 0x04;	// Heartbeat
	my.Save(ADC_In());
	PF2 ^= 0x04;
	PF2 ^= 0x04;
}

