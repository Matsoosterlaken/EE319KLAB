// TableTrafficLight.c edX lab 10, EE319K Lab 5
// Runs on LM4F120 or TM4C123
// Index implementation of a Moore finite state machine to operate a traffic light.  
// Daniel Valvano, Jonathan Valvano
// Feb 27, 2017

/* 
 Copyright 2018 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// See TExaS.h for other possible hardware connections that can be simulated
// east/west red light connected to PE5
// east/west yellow light connected to PE4
// east/west green light connected to PE3
// north/south facing red light connected to PE2
// north/south facing yellow light connected to PE1
// north/south facing green light connected to PE0
// pedestrian detector connected to PA4 (1=pedestrian present)
// north/south car detector connected to PA3 (1=car present)
// east/west car detector connected to PA2 (1=car present)
// "walk" light connected to PF3,2,1 (built-in white LED)
// "don't walk" light connected to PF1 (built-in red LED)
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "SysTick.h"
#include "TExaS.h"


// Declare your FSM linked structure here
struct State {
			uint32_t EOut;
			uint32_t FOut;
			uint32_t Time;
			const struct State *Next[8];
		};
		typedef const struct State STyp;	
void EnableInterrupts(void);

void InitFSM(void){
		STyp FSM[19] = {
			{0x0C,0x02,3000,{&FSM[0],&FSM[0],&FSM[1],&FSM[1],&FSM[3],&FSM[3],&FSM[3],&FSM[3]}}, 
			{0x14,0x02,3000,{&FSM[2],&FSM[2],&FSM[2],&FSM[2],&FSM[4],&FSM[4],&FSM[4],&FSM[4]}},
			{0x24,0x02,3000,{&FSM[5],&FSM[5],&FSM[5],&FSM[5],&FSM[10],&FSM[10],&FSM[10],&FSM[10]}}, 
			{0x14,0x02,3000,{&FSM[4],&FSM[4],&FSM[4],&FSM[4],&FSM[4],&FSM[4],&FSM[4],&FSM[4]}}, 
			{0x24,0x02,3000,{&FSM[10],&FSM[18],&FSM[10],&FSM[18],&FSM[10],&FSM[18],&FSM[10],&FSM[18]}}, 
			{0x21,0x02,3000,{&FSM[5],&FSM[5],&FSM[6],&FSM[6],&FSM[8],&FSM[8],&FSM[8],&FSM[8]}}, 
			{0x22,0x02,3000,{&FSM[7],&FSM[7],&FSM[7],&FSM[7],&FSM[9],&FSM[9],&FSM[9],&FSM[9]}}, 
			{0x24,0x02,3000,{&FSM[0],&FSM[0],&FSM[0],&FSM[0],&FSM[10],&FSM[10],&FSM[10],&FSM[10]}}, 
			{0x22,0x02,3000,{&FSM[9],&FSM[9],&FSM[9],&FSM[9],&FSM[9],&FSM[9],&FSM[9],&FSM[9]}}, 
			{0x24,0x02,3000,{&FSM[10],&FSM[10],&FSM[10],&FSM[10],&FSM[10],&FSM[10],&FSM[10],&FSM[10]}}, 
			{0x24,0x0E,3000,{&FSM[10],&FSM[11],&FSM[11],&FSM[11],&FSM[10],&FSM[11],&FSM[11],&FSM[11]}}, 
			{0x24,0x02,3000,{&FSM[12],&FSM[12],&FSM[12],&FSM[12],&FSM[12],&FSM[12],&FSM[12],&FSM[12]}}, 
			{0x24,0x00,3000,{&FSM[13],&FSM[13],&FSM[13],&FSM[13],&FSM[13],&FSM[13],&FSM[13],&FSM[13]}}, 
			{0x24,0x02,3000,{&FSM[14],&FSM[14],&FSM[14],&FSM[14],&FSM[14],&FSM[14],&FSM[14],&FSM[14]}}, 
			{0x24,0x00,3000,{&FSM[15],&FSM[15],&FSM[15],&FSM[15],&FSM[15],&FSM[15],&FSM[15],&FSM[15]}}, 
			{0x24,0x02,3000,{&FSM[16],&FSM[16],&FSM[16],&FSM[16],&FSM[16],&FSM[16],&FSM[16],&FSM[16]}}, 
			{0x24,0x00,3000,{&FSM[17],&FSM[17],&FSM[17],&FSM[17],&FSM[17],&FSM[17],&FSM[17],&FSM[17]}}, 
			{0x24,0x02,3000,{&FSM[5],&FSM[5],&FSM[0],&FSM[0],&FSM[5],&FSM[5],&FSM[0],&FSM[0]}}, 
			{0x21,0x02,3000,{&FSM[8],&FSM[8],&FSM[8],&FSM[8],&FSM[8],&FSM[8],&FSM[8],&FSM[8]}}, 
	};		
}
int main(void){ 
  TExaS_Init(SW_PIN_PA432, LED_PIN_PE543210); // activate traffic simulation and set system clock to 80 MHz
  SysTick_Init(); 

  // Initialize ports and FSM you write this as part of Lab 5
	InitFSM();	
  EnableInterrupts(); // TExaS uses interrupts
	STyp *current_state = 0;
	uint8_t input = 0;
  while(1){
		current_state = current_state->Next[input]; //this is how to acces the struct
 // FSM Engine
 // you write this as part of Lab 5
    
  }
	
}
	

