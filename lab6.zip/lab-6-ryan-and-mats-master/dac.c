// dac.c
// This software configures DAC output
// Lab 6 requires a minimum of 4 bits for the DAC, but you could have 5 or 6 bits
// Runs on LM4F120 or TM4C123
// Program written by: put your names here
// Date Created: 3/6/17 
// Last Modified: 3/5/18 
// Lab number: 6
// Hardware connections
// TO STUDENTS "REMOVE THIS LINE AND SPECIFY YOUR HARDWARE********

#include <stdint.h>
#include "../inc/tm4c123gh6pm.h"
// Code files contain the actual implemenation for public functions
// this file also contains an private functions and private data

// **************DAC_Init*********************
// Initialize 4-bit DAC, called once 
// Input: none
// Output: none
void DAC_Init(void){	// initialize PB3-0 out
	volatile unsigned long delay;
	SYSCTL_RCGC2_R |= 0x00000002;     																// 1) activate clock for Port B
  delay = SYSCTL_RCGC2_R;          													 				// allow time for clock to start
  GPIO_PORTE_AMSEL_R = 0x00;        																// 3) disable analog on PB
  GPIO_PORTE_PCTL_R = 0x00000000;   																// 4) PCTL GPIO on PB3-0
  GPIO_PORTE_DIR_R = ((GPIO_PORTE_DIR_R & ~(0x0F)) | 0x0F);         // 5) PB3-0 out
  GPIO_PORTE_AFSEL_R = 0x00;       													 				// 6) disable alt funct on PB3-0
  GPIO_PORTE_DEN_R = 0x0F;          																// 7) enable digital I/O on PB3-0
}

// **************DAC_Out*********************
// output to DAC
// Input: 4-bit data, 0 to 15 
// Input=n is converted to n*3.3V/15
// Output: none
void DAC_Out(uint32_t data){					
	GPIO_PORTB_DATA_R = ((GPIO_PORTB_DATA_R & ~(0x0F)) | data); 
}

