# Lab-7
LCD device driver, decimal fixed-point output, local variables, written in assembly (simulated and board, groups of two)
