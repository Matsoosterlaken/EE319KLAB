// IO.c
// This software configures the switch and LED
// You are allowed to use any switch and any LED, 
// although the Lab suggests the SW1 switch PF4 and Red LED PF1
// Runs on LM4F120 or TM4C123
// Program written by: put your names here
// Date Created: March 30, 2018
// Last Modified:  change this or look silly
// Lab number: 7


#include "../inc/tm4c123gh6pm.h"
#include <stdint.h>

//------------IO_Init------------
// Initialize GPIO Port for a switch and an LED
// Input: none
// Output: none
void IO_Init(void) {
	volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x00000020;     																// 1) activate clock for Port F
  delay = SYSCTL_RCGC2_R;          																	// allow time for clock to start
  GPIO_PORTF_LOCK_R = 0x4C4F434B;   																// 2) unlock GPIO Port F
  GPIO_PORTF_CR_R = 0x1F;           																// allow changes to PF4 and PF2
  GPIO_PORTF_AMSEL_R = 0x00;        																// 3) disable analog on PF
	GPIO_PORTF_PCTL_R = 0x00000000;  
  GPIO_PORTF_PUR_R = 0x10;
  GPIO_PORTF_DIR_R = ((GPIO_PORTF_DIR_R & ~(0x04)) | 0x04);         // 5) PF3-1 out
  GPIO_PORTF_AFSEL_R = 0x00;        																// 6) disable alt funct on PF3-1
  GPIO_PORTF_DEN_R = 0x14;
 // --UUU-- Code to initialize PF4 and PF2
}

//------------IO_HeartBeat------------
// Toggle the output state of the  LED.
// Input: none
// Output: none
void IO_HeartBeat(void) {
	GPIO_PORTF_DATA_R ^= 0x04;
 // --UUU-- PF2 is heartbeat
}


//------------IO_Touch------------
// wait for release and press of the switch
// Delay to debounce the switch
// Input: none
// Output: none
void IO_Touch(void) {
	while (GPIO_PORTF_DATA_R & 0x10){
	}	
	//delay(); TODO
	while (!(GPIO_PORTF_DATA_R & 0x10)){
	}	
 // --UUU-- wait for release; delay for 20ms; and then wait for press
}  

